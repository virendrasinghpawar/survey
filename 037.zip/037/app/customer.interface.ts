export interface Customer {
    Title: string;
    // addresses: Address[];
    Choices:Choice[];
}

export interface Choice {
    choice: string;
    
}